'use strict';

hexo.extend.helper.register('icon', function(key, args) {
  return hexo.utils.icon(key, args)
})
